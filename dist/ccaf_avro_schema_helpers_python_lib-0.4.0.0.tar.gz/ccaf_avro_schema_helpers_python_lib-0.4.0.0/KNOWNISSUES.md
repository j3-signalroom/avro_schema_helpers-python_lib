# Known Issues
All notable known issues to this project will be documented in this file.

* Issue [#30](https://github.com/j3-signalroom/ccaf-avro_schema_helpers-python_lib/issues/30) - The primary keys are set and hardcoded.